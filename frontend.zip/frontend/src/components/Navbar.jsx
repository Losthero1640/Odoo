import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <nav className="navbar">
      <Link to="/" className="nav-logo">
        ItemSwap
      </Link>
      <div className="nav-links">
        <Link to="/browse">Browse Items</Link>
        {user && <Link to="/add-item">List an Item</Link>}
        {user && <Link to="/">Dashboard</Link>}
        {user && user.isAdmin && <Link to="/admin">Admin</Link>}
        {!user && <Link to="/signup">Sign Up</Link>}
        {!user && <Link to="/login">Login</Link>}
        {user && (
          <button onClick={handleLogout} className="btn-logout">
            Logout
          </button>
        )}
      </div>
         
    </nav>
  );
}
