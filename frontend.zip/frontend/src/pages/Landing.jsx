import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function Landing() {
  const [featured, setFeatured] = useState([]);

  useEffect(() => {
    fetch("http://localhost:4000/api/items/featured")
      .then((res) => res.json())
      .then(setFeatured)
      .catch(console.error);
  }, []);

  return (
    <div>
      <section className="intro text-center py-8">
        <h1 className="text-4xl font-bold mb-2">Welcome to ItemSwap</h1>
        <p className="text-lg mb-4">
          Swap your unwanted items or redeem with points! Join our community
          today.
        </p>
        <div className="flex justify-center gap-4">
          <Link to="/browse" className="btn">
            Browse Items
          </Link>
          <Link to="/add-item" className="btn btn-primary">
            List an Item
          </Link>
          <Link to="/signup" className="btn">
            Start Swapping
          </Link>
        </div>
      </section>

      <section className="featured-items py-8 px-4">
        <h2 className="text-2xl font-semibold mb-4">Featured Items</h2>
        <div className="carousel grid grid-cols-1 md:grid-cols-3 gap-4">
          {featured.length === 0 && <p>Loading featured items...</p>}
          {featured.map((item) => (
            <div
              key={item._id}
              className="carousel-item bg-white p-4 shadow-md rounded-md"
            >
              {item.imagePaths.length > 0 && (
                <img
                  src={`http://localhost:4000${item.imagePaths[0]}`}
                  alt={item.title}
                  className="carousel-image mb-2 w-full h-48 object-cover rounded"
                />
              )}
              <h3 className="text-xl font-bold">{item.title}</h3>
              <p className="text-sm text-gray-600">{item.category}</p>
              <Link
                to={`/items/${item._id}`}
                className="btn btn-small mt-2 inline-block"
              >
                View
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
