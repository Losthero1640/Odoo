import React, { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";

const API_URL = "http://localhost:4000/api";

export default function Browse() {
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [searchParams] = useSearchParams();

  const category = searchParams.get("category") || "";
  const tags = searchParams.get("tags") || "";

  useEffect(() => {
    setLoading(true);

    let url = `${API_URL}/items?page=${page}&limit=12`;

    if (category) url += `&category=${encodeURIComponent(category)}`;
    if (tags) url += `&tags=${encodeURIComponent(tags)}`;

    fetch(url)
      .then((res) => res.json())
      .then((data) => {
        setItems(data.items);
        setPages(data.pages);
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  }, [page, category, tags]);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Browse Items</h2>

      {loading && <p>Loading...</p>}
      {!loading && items.length === 0 && <p>No items found.</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {items.map((item) => (
          <div key={item._id} className="item-card border p-4 rounded shadow">
            {item.imagePaths.length > 0 && (
              <img
                src={`http://localhost:4000${item.imagePaths[0]}`}
                alt={item.title}
                className="w-full h-40 object-cover mb-2 rounded"
              />
            )}
            <h3 className="font-semibold text-lg">{item.title}</h3>
            <p className="text-gray-600">{item.category}</p>
            <Link to={`/items/${item._id}`} className="btn mt-2 inline-block">
              View
            </Link>
          </div>
        ))}
      </div>

      <div className="pagination flex items-center justify-center gap-4 mt-6">
        <button
          disabled={page <= 1}
          onClick={() => setPage((p) => p - 1)}
          className="btn"
        >
          Prev
        </button>
        <span>
          Page {page} / {pages}
        </span>
        <button
          disabled={page >= pages}
          onClick={() => setPage((p) => p + 1)}
          className="btn"
        >
          Next
        </button>
      </div>
    </div>
  );
}
