import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";

const API_URL = "http://localhost:4000/api";

export default function AdminPanel() {
  const { token } = useAuth();
  const [pendingItems, setPendingItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [actionStatus, setActionStatus] = useState(null);

  useEffect(() => {
    fetchPendingItems();
  }, []);

  const fetchPendingItems = () => {
    setLoading(true);
    fetch(`${API_URL}/admin/items/pending`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (res) => {
        if (!res.ok) {
          const e = await res.json();
          throw new Error(e.message || "Failed to load pending items");
        }
        return res.json();
      })
      .then((data) => {
        setPendingItems(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  };

  const approveItem = async (itemId) => {
    setActionStatus(null);
    const res = await fetch(`${API_URL}/admin/items/${itemId}/approve`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (res.ok) {
      setActionStatus("Item approved.");
      fetchPendingItems();
    } else {
      setActionStatus(data.message || "Error approving item.");
    }
  };

  const rejectItem = async (itemId) => {
    if (
      !window.confirm("Are you sure you want to reject and delete this item?")
    )
      return;
    setActionStatus(null);
    const res = await fetch(`${API_URL}/admin/items/${itemId}/reject`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (res.ok) {
      setActionStatus("Item rejected and deleted.");
      fetchPendingItems();
    } else {
      setActionStatus(data.message || "Error rejecting item.");
    }
  };

  if (loading) return <p>Loading admin panel...</p>;
  if (error) return <p className="alert">{error}</p>;

  return (
    <div>
      <h2>Admin Panel - Moderate Listings</h2>
      {actionStatus && <p className="feedback">{actionStatus}</p>}
      {pendingItems.length === 0 ? (
        <p>No pending items for approval.</p>
      ) : (
        <div className="item-grid">
          {pendingItems.map((item) => (
            <div key={item._id} className="item-card">
              {item.imagePaths.length > 0 && (
                <img
                  src={`http://localhost:4000${item.imagePaths[0]}`}
                  alt={item.title}
                  className="item-image"
                />
              )}
              <h4>{item.title}</h4>
              <p>
                <strong>Uploader:</strong>{" "}
                {item.uploader.profileDetails?.fullName || item.uploader.email}
              </p>
              <p>
                <strong>Category:</strong> {item.category}
              </p>
              <p>
                <strong>Description:</strong> {item.description}
              </p>
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => approveItem(item._id)}
                  className="btn btn-primary"
                >
                  Approve
                </button>
                <button
                  onClick={() => rejectItem(item._id)}
                  className="btn btn-danger"
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
