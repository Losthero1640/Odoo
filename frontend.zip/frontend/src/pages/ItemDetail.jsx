import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const API_URL = "http://localhost:4000/api/items";

export default function ItemDetail() {
  const { id } = useParams();
  const { user, token } = useAuth();
  const [item, setItem] = useState(null);
  const [error, setError] = useState(null);
  const [swapStatus, setSwapStatus] = useState(null);
  const [redeemStatus, setRedeemStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  useEffect(() => {
    setLoading(true);
    fetch(`${API_URL}/${id}`)
      .then(async (res) => {
        if (!res.ok) {
          const err = await res.json();
          throw new Error(err.message || "Failed to load item");
        }
        return res.json();
      })
      .then((data) => {
        setItem(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [id]);

  const requestSwap = async () => {
    setSwapStatus(null);
    setRedeemStatus(null);
    if (!user) {
      setSwapStatus("Please login to request a swap.");
      return;
    }
    const res = await fetch(`${API_URL}/${id}/swap-request`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (res.ok) setSwapStatus("Swap request submitted.");
    else setSwapStatus(data.message || "Error requesting swap.");
  };

  const redeemItem = async () => {
    setSwapStatus(null);
    setRedeemStatus(null);
    if (!user) {
      setRedeemStatus("Please login to redeem items.");
      return;
    }
    const res = await fetch(`${API_URL}/${id}/redeem`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    if (res.ok) setRedeemStatus("Item redeemed successfully!");
    else setRedeemStatus(data.message || "Error redeeming item.");
  };

  if (loading) return <p>Loading item...</p>;
  if (error) return <p className="alert">{error}</p>;
  if (!item) return null;

  const uploaderName =
    item.uploader &&
    (item.uploader.profileDetails?.fullName || item.uploader.email);

  return (
    <div className="item-detail p-6">
      <h2 className="text-2xl font-bold mb-2">
        {item.title} <small className="text-gray-500">({item.category})</small>
      </h2>

      <div className="image-gallery mb-4">
        {item.imagePaths.length > 0 && (
          <>
            <img
              key={item.imagePaths[activeImageIndex]}
              src={`http://localhost:4000${item.imagePaths[activeImageIndex]}`}
              alt={`Image ${activeImageIndex + 1}`}
              className="main-image w-full h-64 object-cover rounded"
            />
            <div className="thumbnail-row flex gap-2 mt-2">
              {item.imagePaths.map((p, idx) => (
                <img
                  key={p}
                  src={`http://localhost:4000${p}`}
                  alt={`Thumb ${idx + 1}`}
                  className={`thumb w-16 h-16 object-cover rounded cursor-pointer ${
                    activeImageIndex === idx ? "ring-2 ring-blue-500" : ""
                  }`}
                  onClick={() => setActiveImageIndex(idx)}
                />
              ))}
            </div>
          </>
        )}
      </div>

      <div className="space-y-2">
        <p>
          <strong>Description:</strong>{" "}
          {item.description || "No description provided."}
        </p>
        <p>
          <strong>Type:</strong> {item.type || "-"}
        </p>
        <p>
          <strong>Size:</strong> {item.size || "-"}
        </p>
        <p>
          <strong>Condition:</strong> {item.condition || "-"}
        </p>
        <p>
          <strong>Tags:</strong>{" "}
          {item.tags.length > 0 ? item.tags.join(", ") : "-"}
        </p>
        <p>
          <strong>Availability:</strong> {item.availability}
        </p>
        <p>
          <strong>Uploaded by:</strong> {uploaderName || "Unknown"}
        </p>
      </div>

      <div className="item-actions mt-4 space-x-2">
        {item.availability === "available" &&
          user &&
          user.id !== item.uploader._id && (
            <>
              <button onClick={requestSwap} className="btn btn-primary">
                Swap Request
              </button>
              <button onClick={redeemItem} className="btn btn-secondary">
                Redeem via Points
              </button>
            </>
          )}
        {!user && (
          <p className="text-gray-600 mt-2">
            Login to request a swap or redeem this item.
          </p>
        )}
      </div>

      {swapStatus && <p className="feedback mt-2">{swapStatus}</p>}
      {redeemStatus && <p className="feedback mt-2">{redeemStatus}</p>}
    </div>
  );
}
