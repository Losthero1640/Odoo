import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { Link } from "react-router-dom";

const API_URL = "http://localhost:4000/api/user/dashboard";

export default function Dashboard() {
  const { token } = useAuth();
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    fetch(`${API_URL}/user/dashboard`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (res) => {
        if (!res.ok) {
          const e = await res.json();
          throw new Error(e.message || "Failed to load dashboard");
        }
        return res.json();
      })
      .then((data) => {
        setDashboardData(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [token]);

  if (loading) return <p>Loading dashboard...</p>;
  if (error) return <p className="alert">{error}</p>;
  if (!dashboardData) return null;

  const { user, uploadedItems, swapsRequested } = dashboardData;

  return (
    <div>
      <h2>Dashboard</h2>

      <section className="profile-info">
        <h3>Profile</h3>
        <p>
          <strong>Email:</strong> {user.email}
        </p>
        <p>
          <strong>Full Name:</strong>{" "}
          {user.profileDetails?.fullName || "Not set"}
        </p>
        <p>
          <strong>Points Balance:</strong> {user.points}
        </p>
      </section>

      <section className="uploaded-items">
        <h3>Your Uploaded Items</h3>
        {uploadedItems.length === 0 ? (
          <p>You have not uploaded any items yet.</p>
        ) : (
          <div className="item-grid">
            {uploadedItems.map((item) => (
              <div key={item._id} className="item-card">
                {item.imagePaths.length > 0 && (
                  <img
                    src={`http://localhost:4000${item.imagePaths[0]}`}
                    alt={item.title}
                    className="item-image"
                  />
                )}
                <h4>{item.title}</h4>
                <p>Status: {item.approved ? "Approved" : "Pending Approval"}</p>
                <p>Availability: {item.availability}</p>
                <Link to={`/items/${item._id}`} className="btn btn-small">
                  View
                </Link>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="swaps-requested">
        <h3>Ongoing and Completed Swaps</h3>
        {swapsRequested.length === 0 ? (
          <p>You have not requested any swaps yet.</p>
        ) : (
          <ul className="swap-list">
            {swapsRequested.map((swap) => (
              <li key={swap._id}>
                <Link to={`/items/${swap.item._id}`}>{swap.item.title}</Link> -
                Status: {swap.status} - Availability: {swap.item.availability}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
